<table align="center" width="100%" cellpadding="0" cellspacing="0" >    
	<tr>
        <td  valign="top">
            <div id="dhtmlgoodies_xpPane">
                <div class="dhtmlgoodies_panel">
                    <div>
                        <a href="my_applications.php">My Applications</a><br/><br/>
                           
                        
                    </div>	
                </div>     		
		<div class="dhtmlgoodies_panel">
                    <div>
                    <br />
                    <a href="fee_structure_list.php">Fee Structure</a><br/><br/>
                    <a href="seat_list.php">Seat Management</a><br/><br/> 
                    <a href="dashB.php">Seat Availability</a><br />&nbsp;
                    </div>	
                </div>
						          
                <div class="dhtmlgoodies_panel">
                    <div>
                    <br />
                        <a href="change_password.php">Change Password</a><br/><br/>
                        <a href="logout.php">Logout</a>
                        <br />&nbsp;
                    </div>	
                </div>
              
            </div>
        </td>
	</tr>
</table>
<script type="text/javascript">
	initDhtmlgoodies_xpPane(Array('My Application','Report','System'),Array(true,true,true,true),Array('pane1','pane2','pane3'));
</script>