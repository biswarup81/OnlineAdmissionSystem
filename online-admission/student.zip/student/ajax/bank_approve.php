<?php
include("../../config.php");
mysql_query("UPDATE `application_table` SET `Bank_Payment_Verified`=1 where `id`='".$_REQUEST[id]."'");
?>