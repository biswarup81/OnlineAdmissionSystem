<?php
include("../../config.php");
$draftTosubmit="<p>Thank you for Submitting your Application for Chandidas College. Kindly wait for the Merit List for result.</p>";
$draftRankedToAdmit = "<p>Thank you for taking admission to Chandidas College. Kindly go to college on 05-06-2014 with all your original copies</p>";
$confirmAdmission = "<p>Student has been admitted successfully</p>";
$inputFlag = filter_input(INPUT_GET, 'flag');
$inputId = filter_input(INPUT_GET, 'id');
$query = "UPDATE `application_table` SET `flag`='".$inputFlag."' where `id`='".$inputId."'";
mysql_query($query)or die(mysql_error());

if($inputFlag == 2){
    echo $draftTosubmit;
} else if($inputFlag == 4){
    echo $draftRankedToAdmit;
} else if($inputFlag == 5){
    echo $confirmAdmission;
}

//echo $inputFlag;
//echo "Updated with ==> ".$query;
?>