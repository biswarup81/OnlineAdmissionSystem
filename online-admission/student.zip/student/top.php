<?php
ob_start();
require "../lib/config.php";
require "../lib/mysql.php";
require "../lib/functions.php";
require "../lib/conn.php";

$admin_pagelist=20;
$f_limit=f(q("select * from dt_charlimit"));
$for_msg=$f_limit['for_msg'];
$for_ad=$f_limit['for_ad'];
?>