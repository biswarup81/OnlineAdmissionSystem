<?php 
include "top.php";
include "header.php";
?>
<p><strong>Welcome to Chandrapur College Student Panel. Please click the menus on the left side to operate</strong></p>
<?php include "footer.php";?>