<?php
/**Developer: Anish Karim C*[thecoderin@gmail.com]*****                       *     *     *
***FileFor: MySQL Database BackUP[config.php]***********                        *   *   *
***CreatedOn: 19th November 2009*****************************                     * * *
***Modified On: 03 December 2009 *******************************             * * *  C  * * *
***************************************************************			  * * *
***Details: configuration file. All data enters here**********			*   *   *
***Suggestions and Comments are welcome******************		      *     *     *
*/

//Back Up Folder*
$backUpFolder	= "payout_backup"; // The folder which the sql file stored. It is needed

@mkdir($backUpFolder);	//Create  Back Up Directory
@chmod($backUpFolder,0777); // Make it writable. In Case it already there.

//Database Server Details*
/*
$server['host']	= "localhost";	//The hostname
$server['port']	= "";	//Give the port number allocated for MySQL. Leave blank if it is default[3306]
$server['user']	= "root";	//MySQLDatabase Username. Need to have all permission to the database.
$server['pass']	= "";	//MySQLDatabase Password.
$server['database']	= "dkm";	//MySQLDatabase Name.
*/

//For Server Configuration
$server['host']	= "localhost";	//The hostname
//$server['port']	= "";	//Give the port number allocated for MySQL. Leave blank if it is default[3306]
$server['user']	= "root";	//MySQLDatabase Username. Need to have all permission to the database.
$server['pass']	= "";	//MySQLDatabase Password.
$server['database']	= "khuj_oadb";	//MySQLDatabase Name.

//Mailing Details*
$mailer["FromMail"]	= "db_manager@yoursite.com"; //From e-mail address. If you don't want to specify leave it blank
$mailer["ToMail"]	= "developer@yoursite.com"; // Address which the mail should send. If no mailing is needed, Please leave it blank.
$mailer["MailBody"]	= "Message Body";	//Body of the mail
$mailer["DAS"]	= false;	//Change it to true when the file in the server needs to remove after finish sending mail. Default is false.
//For more details Please visit: http://is.gd/5b3Xk
?>
